# rdsation

Landing page de migração da RD Station para o ActiveCampaign, com implementação e migração inclusas pelo time ao contratar pelo link de parceiro.

Página estática, arquivo único (`index.html`), sem dependências além do Google Fonts.

## Publicar com GitHub Pages

1. Settings > Pages
2. Source: Deploy from a branch
3. Branch: `main`, pasta `/ (root)`
4. A página fica em `https://SEU-USUARIO.github.io/rdsation/`
